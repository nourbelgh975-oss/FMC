/* FMC — comportement global : nav mobile, tweaks panel persistants */
(function () {
  const STORAGE_KEY = "fmc-tweaks-v1";

  const defaults = {
    color: "violet", // violet | indigo | mauve | aubergine
    serif: "cormorant", // cormorant | playfair | spectral
    density: "comfortable", // compact | comfortable | airy
    ornaments: "on", // on | off
  };

  function loadTweaks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...defaults };
      return { ...defaults, ...JSON.parse(raw) };
    } catch (e) { return { ...defaults }; }
  }
  function saveTweaks(t) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(t)); } catch (e) {}
  }

  const COLORS = {
    violet:    { 900: "#2A2152", 800: "#3A2F70", 700: "#4A3B8C", 600: "#6354A8", 100: "#E8E3F2" },
    indigo:    { 900: "#1F2148", 800: "#2A2D6E", 700: "#3D429A", 600: "#5860B5", 100: "#E0E2F0" },
    mauve:     { 900: "#3A1F46", 800: "#5A2F6E", 700: "#7C4292", 600: "#9968B0", 100: "#EFE3F0" },
    aubergine: { 900: "#2C1A35", 800: "#42284F", 700: "#5C3A6C", 600: "#7A5589", 100: "#E8DFEC" },
  };

  const SERIFS = {
    cormorant: '"Cormorant Garamond", "Cormorant", Georgia, serif',
    playfair:  '"Playfair Display", Georgia, serif',
    spectral:  '"Spectral", Georgia, serif',
  };

  function applyTweaks(t) {
    const root = document.documentElement;
    const c = COLORS[t.color] || COLORS.violet;
    root.style.setProperty("--violet-900", c[900]);
    root.style.setProperty("--violet-800", c[800]);
    root.style.setProperty("--violet-700", c[700]);
    root.style.setProperty("--violet-600", c[600]);
    root.style.setProperty("--violet-100", c[100]);
    root.style.setProperty("--serif", SERIFS[t.serif] || SERIFS.cormorant);
    root.dataset.density = t.density;
    root.dataset.ornaments = t.ornaments;
  }

  function renderTweaksPanel(state, onChange) {
    const panel = document.querySelector(".tweaks-panel");
    if (!panel) return;

    panel.querySelectorAll("[data-tweak]").forEach((group) => {
      const key = group.dataset.tweak;
      group.querySelectorAll("[data-value]").forEach((el) => {
        el.dataset.active = (el.dataset.value === state[key]) ? "true" : "false";
        el.onclick = () => {
          const next = { ...state, [key]: el.dataset.value };
          Object.assign(state, next);
          applyTweaks(state);
          saveTweaks(state);
          renderTweaksPanel(state, onChange);
        };
      });
    });
  }

  function setupNav() {
    const toggle = document.querySelector(".nav-toggle");
    const list = document.querySelector(".nav-links");
    if (!toggle || !list) return;
    const close = () => list.classList.remove("is-open");
    toggle.addEventListener("click", () => {
      list.classList.toggle("is-open");
    });
    list.querySelectorAll("a").forEach(a => a.addEventListener("click", close));
    // click on the X (pseudo-element area, top-right of fixed overlay)
    list.addEventListener("click", (e) => {
      if (!list.classList.contains("is-open")) return;
      const rect = list.getBoundingClientRect();
      if (e.clientY < rect.top + 60 && e.clientX > rect.right - 80) close();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") close();
    });
  }

  function setupTweaks() {
    const fab = document.querySelector(".tweaks-fab");
    const panel = document.querySelector(".tweaks-panel");
    if (!fab || !panel) return;

    const state = loadTweaks();
    applyTweaks(state);
    renderTweaksPanel(state);

    fab.dataset.show = "true";
    fab.addEventListener("click", () => {
      panel.dataset.open = panel.dataset.open === "true" ? "false" : "true";
    });
    const close = panel.querySelector(".tweaks-panel__close");
    if (close) close.addEventListener("click", () => { panel.dataset.open = "false"; });
  }

  // Apply tweaks ASAP to avoid flash
  applyTweaks(loadTweaks());

  document.addEventListener("DOMContentLoaded", () => {
    setupNav();
    setupTweaks();
  });
})();
